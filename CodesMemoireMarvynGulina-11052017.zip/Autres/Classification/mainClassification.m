% Classification de signal 
% ************************

% Programme principal
% -------------------

clc; close all; clearvars; format short;

%% 1 - Construction de la fonction cible
tic;
cibleClass;
DureeCible = toc;

%% 2 - Construction du r�servoir
tic;
genResClass;
DureeGenRes = toc;

%% 3 - Entra�nement du r�servoir
tic;
trainClass;
DureeTrain = toc;
    
%% 4 - Calcul d'erreur et affichage
tic;
calcErreursTrain;
set(figErreurRC,'visible','on'); pause(10^-1);
% set(figCible,'visible','on'); pause(10^-1);
DureeErreur = toc;

Duree = DureeCible + DureeGenRes + DureeTrain + DureeErreur;