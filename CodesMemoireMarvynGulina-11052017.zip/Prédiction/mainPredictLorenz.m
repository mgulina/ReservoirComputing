% Emulation de syst�me chaotique par ESN
% **************************************

% Programme principal pour Lorenz
% -------------------------------

clc; close all; clear; format short;

%% 1 - Construction de la fonction cible
tic;
cibleLorenz;
DureeCible = toc;

%% 2 - Construction du r�servoir
tic;
genResLorenz;
DureeGenRes = toc;

%% 3 - Entra�nement du r�servoir
tic;
tauTrain = 0; % Retard entre le RC et le Lorenz en unit� de pas d'int�gration
trainSimpleLorenz;
% TrainAvanceLorenz; % A mettre � jour
DureeTrain = toc;

%% 4 - Calcul d'erreur et affichage
tic;
calcErreursTrain;
set(figErreurRC,'visible','on'); pause(10^-1);
DureeErreur = toc;

%% 5 - Tests suppl�mentaires
tic;
% testChaos;
DureeTests = toc;

Duree = DureeCible + DureeGenRes + DureeTrain + DureeErreur + DureeTests;