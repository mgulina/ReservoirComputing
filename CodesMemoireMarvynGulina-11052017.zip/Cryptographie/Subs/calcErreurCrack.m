% Cryptographie chaotique
% ***********************
% 
% Calcul d'erreurs pour la superposition (Eve)
% --------------------------------------------

%% 1 - Erreur de d�cryptage
T_tot = (length(Crypt) - 1)*h; T_out = 0:h:T_tot; T = length(T_out);

% if Q ~= 1
%     interpMessage = interp1(T_out,Message,interpT_out);
%     interpMessage = filtreSortieEve(interpMessage,A/2,Q*bitRepete);
%     interpMessage(interpMessage == 1) = A;
% end

% if Q ~= 1
%     ErreurCrack = Crack - interpMessage;
%     ErreurCrackFiltre = CrackFiltre - interpMessage;
% else
    ErreurCrack = Crack - Message;
    ErreurCrackFiltre = CrackFiltre - Message;
% end

% nbrErreurCrack = sum(abs(ErreurCrackFiltre)/A)/(Q*bitRepete) %#ok<*NOPTS>
nbrErreurCrack = sum(abs(ErreurCrackFiltre)/A)/(bitRepete) %#ok<*NOPTS>
SER = nbrErreurCrack/(nbrBit)

%% 2 - Sorties graphiques
figCrack = figure('units','normalized',...
        'outerposition',[0.06  0.21  0.7 0.7],...
        'Name','D�codage',...
        'Visible','Off');
    
subplot(211);
    plot(T_out,Message,'b-o');hold on;
    plot(T_out,Crack,'r-x');
    plot(T_out,CrackFiltre,'g-*');
    plot([0 T_out(end)],[M M],'k');
    xlabel('t [s]');
    ylim([-A 2*A]);
    title('Comparaison entre le message original et decod�');
    legend('Original','Decod� sans filtre','Decod� avec filtre',...
           'Location','Best');
    
subplot(212);    
    plot(T_out,ErreurCrackFiltre,'g-*');
    xlabel('t [s]');
    title('Diff�rence entre le message original et decod�');

% set(figCrack,'visible','on'); pause(10^-1);