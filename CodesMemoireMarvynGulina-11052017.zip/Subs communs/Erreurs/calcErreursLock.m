 %% 1 - Erreurs
EA_lock = abs(lock-primaire);
ER_lock = EA_lock./abs(primaire);

% On calcule la MSE � partir du premier minimum de l'erreur absolue
T_lock = find(EA_lock == min(EA_lock),1);
lockSeq = T_lock:T;
mse_lock = mean(EA_lock(lockSeq).^2);

log10_mse_lock = log10(mse_lock) %#ok<*NOPTS>

%% 2 - Affichage
subplot(211); hold on;
    plot(T_out,primaire,'b-x'); 
    plot(T_out,lock,'r-o');
    plot(T_out,unlock,'k');
    title('Comparaison de l''�volution des syst�mes');
    xlabel('t');
    legend('Primaire','Verrouill�','Non verrouill�',...
        'Location','SouthEast');

subplot(212); hold on;
    plot(T_out,log10(ER_lock),'g-*'); hold on;
    plot(T_out,EA_lock,'b-*');
    title('Evolution de l''erreur relative entre le primaire et le verrouill�');
    xlabel('t');
    legend('Log de l''erreur relative','Erreur absolue',...
        'Location','SouthEast');