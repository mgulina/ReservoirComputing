function x = id(x)
    % Fonction idendit�
end