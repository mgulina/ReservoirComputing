% Cryptographie chaotique
% ***********************
% 
% Calcul d'erreurs pour la superposition (Bob)
% --------------------------------------------

%% 1 - Erreur de d�cryptage
ErreurDecrypt = Decrypt - Message;
ErreurDecryptFiltre = DecryptFiltre - Message;

nbrErreurDecrypt = sum(abs(ErreurDecryptFiltre)/A)/bitRepete %#ok<*NOPTS>
SER = nbrErreurDecrypt/nbrBit

%% 2 - Sorties graphiques
figDecrypt = figure('units','normalized',...
        'outerposition',[0.06  0.21  0.7 0.7],...
        'Name','D�cryptage',...
        'Visible','Off');
    
subplot(211);
    plot(T_out,Message,'b-o');hold on;
    plot(T_out,Decrypt,'r-x');
    plot(T_out,DecryptFiltre,'g-*');
    plot([0 T_out(end)],[A/2 A/2],'k');
    xlabel('t [s]');
    if A > 0
        ylim([-A 2*A]);
    else
%         ylim([2*A -A]);
    end
    title('Comparaison entre le message original et d�crypt�');
    legend('Original','D�crypt� sans filtre','D�crypt� avec filtre',...
           'Location','Best');
    
subplot(212);    
    plot(T_out,ErreurDecryptFiltre,'g-*');
    xlabel('t [s]');
    title('Diff�rence entre le message original et d�crypt�');

% set(figDecrypt,'visible','on'); pause(10^-1);