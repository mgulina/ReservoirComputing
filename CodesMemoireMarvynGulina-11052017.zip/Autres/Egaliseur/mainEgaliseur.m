% Emulation de syst�me chaotique par ESN
% **************************************

% Programme principal pour l'�galiseur de canaux
% ----------------------------------------------

clc; close all; clearvars; format short;

%% 1 - Construction de la fonction cible
tic;
dataEgaliseur;
DureeCible = toc;

%% 2 - Construction du r�servoir
tic;
genResEgaliseur;
DureeGenRes = toc;

%% 3 - Entra�nement du r�servoir
tic;
trainEgaliseur;
DureeTrain = toc;

%% 4 - Calcul d'erreur et affichage
tic;
calcErreurEgaliseur;
DureeErreur = toc;

Duree = DureeCible + DureeGenRes + DureeTrain + DureeErreur;