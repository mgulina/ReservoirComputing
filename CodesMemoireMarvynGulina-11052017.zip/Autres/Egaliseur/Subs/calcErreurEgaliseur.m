% Filtre de sortie et v�rification des erreurs pour l'�galiseur de canaux
% ***********************************************************************

nbrErreurTrain
stop
nbrErreurLibre

%% 1 - Symbol Error Rate
nbrErreurMax = 10;
if nbrErreurLibre == nbrErreurMax
    ser = nbrErreurMax/length(trainEnd+1:posErreurLibre(nbrErreurMax)) %#ok<*NOPTS>
else    
    ser = nbrErreurLibre/length(trainEnd+1:T)
end

%% 2 - Affichage
fig1 = figure('units','normalized',...
        'outerposition',[0.06  0.16  0.7 0.75],...
        'Visible','Off');

subplot(411);
    plot(d(1:1000),'bo'); hold on; 
    title('1000 premi�res entr�es du canal');
    xlabel('t');
    
subplot(412);
    plot(q(1:1000),'bo'); hold on; 
    title('1000 premi�res sorties du canal');
    xlabel('t');    
    
subplot(413);
    plot(trainSeq,d(trainSeq-delai),'bo'); hold on; 
    plot(trainSeq,y_hat(trainSeq),'rx');
    plot(trainSeq,d_hat(trainSeq),'g*');
    title('Comparaison entre fonction cible et entra�n�e');
    xlabel('t'); xlim([transient transient+trainEnd/2]);
    legend('Symboles cibles','Entrainement sans filtre','Avec filtre',...
        'Location','EastOutside');
    
subplot(414);
    plot(trainEnd+delai:T,d((trainEnd:T-delai))','bo'); hold on;
    plot(trainEnd+delai:T,y_hat(trainEnd+delai:T),'rx');
    plot(trainEnd+delai:T,d_hat(trainEnd+delai:T),'g*');
    title('Comparaison entre fonction cible et �galis�e');
    xlabel('t'); xlim([trainEnd trainEnd+trainEnd/2]);     
    legend('Symboles cibles','Egalisation sans filtre','Avec filtre',...
        'Location','EastOutside');
    
set(fig1,'visible','on');

clear t;