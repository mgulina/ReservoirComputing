% Cryptographie chaotique
% ***********************

% Eve (sans exemple)
% ------------------

disp('Eve');

%% 1 - Entra�nement du r�servoir
% CI = 0.5; clearvars T T_out T_tot rk4;
% ChangeScaleMG = 0;
% cibleMG;
bruitTrain = unifrnd(-A_eps,A_eps,size(Cible)); Cible = Cible + bruitTrain; clear bruitTrain;

genResMG;

% interpT_out = T_out;
transient = round(nbrBitLock/5);   trainEnd = T-1;     test84 = T;     fullTrain = 1;
trainSimpleMG;
calcErreursTrain;

%% 2 - Verrouillage du syst�me de Bob sur celui de Alice 
%% 1.2 - R�cup�ration des donn�es du RC
% Etat final
s = S(end,:);
SLock = zeros(T,N+K); SLock(1,:) = s;

% Fonction d'activtion
u = 0.2*ones(1,T);

% Niveaux de Bruit
LvlNoiseRC = LvlNoise;
LvlNoiseVerrou = 0;

%% 1.3 - Conditions initiales des syt�mes primaire et secondaires
lock = zeros(T,1);

%% 1.4 - Efficacit� du verrouillage
q = 0.95;
p = 1-q; % MG'(t) = p*f(MG'(t-tau)) + q*MG(t)

%% 2 - verrouillage
for t = 1:T-1
  
    if t < nbrBitLock*bitRepete    
         lock(t) = p*W_out*SLock(t,:)' +(1-p)*(Crypt(t) ...
              + unifrnd(-LvlNoiseVerrou,LvlNoiseVerrou,1,1));
         SLock(t+1,:) = majRes(f_RC,delta,a,C,W_in,W,W_fb,SLock(t,1:N)',...
                      u(:,t+1),lock(t),unifrnd(-LvlNoiseRC,LvlNoiseRC,N,1));
    else
         lock(t) = W_out*SLock(t,:)';
         SLock(t+1,:) = majRes(f_RC,delta,a,C,W_in,W,W_fb,SLock(t,1:N)',...
                      u(:,t+1),lock(t),unifrnd(-LvlNoiseRC,LvlNoiseRC,N,1));
    end
end
lock(T) = p*W_out*SLock(T,:)';

if ChangeScaleMG
    lock = atanh(lock) + 1;
end

%% 3 - D�cryptage
Crack = Crypt - lock';
% M = mean(Crack(Q*150:end));
% M = mean(Crack(150:end));
M = A/2;
% CrackFiltre = filtreSortieEve(Crack,M,Q*bitRepete);
CrackFiltre = filtreSortieEve(Crack,M,bitRepete);
CrackFiltre(CrackFiltre == 1) = A;

%% 4 - Calcul d'erreur et affichage
calcErreurCrack;


















% %% 2 - D�cryptage
% T_tot = (length(Crypt) - 1)*h; T_out = 0:h:T_tot; T = length(T_out);
% u = 0.2*ones(1,T);
% S = zeros(T,N+K); S(1,:) = [zeros(N,1) ; u(:,1)]';
% Crack = zeros(1,T);
% 
% CryptTransient = 150;
% for t = 1:CryptTransient
% S(t+1,:) = majRes(f_RC,delta,a,C,W_in,W,W_fb,...
%                       S(t,1:N)', u(:,2), Crypt(t),...
%                       unifrnd(-LvlNoise,LvlNoise,N,1));
% end
% 
% for t = CryptTransient+1:T-1
%     PorteuseTrain = W_out*S(t,:)';
%     Crack(t) = Crypt(t) - PorteuseTrain;
%     S(t+1,:) = majRes(f_RC,delta,a,C,W_in,W,W_fb,...
%                       S(t,1:N)', u(:,t+1), Crypt(t),...
%                       unifrnd(-LvlNoise,LvlNoise,N,1));
% end
% 
% %% 3 - Filtre en sortie
% M = mean(Crack(150:end));
% CrackFiltre = filtreSortieEve(Crack,M,bitRepete);
% CrackFiltre(CrackFiltre == 1) = A;
% 
% %% 4 - Calcul d'erreur et affichage
% calcErreurCrack;