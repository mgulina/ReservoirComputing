% Emulation de syst�me chaotique par ESN
% **************************************

% Programme principal pour fonction p�riodique al�atoire
% ------------------------------------------------------

clc; close all; clearvars; format short;

%% 1 - Construction de la fonction cible
tic;
cibleFctPerAle;
DureeCible = toc;

%% 2 - Construction du r�servoir
tic;
genResFctPerAle;
DureeGenRes = toc;

%% 3 - Entra�nement du r�servoir
tic;
theta = 0;
trainFctAleaPer;
DureeTrain = toc;

%% 4 - Calcul d'erreur et affichage
tic;
calcErreursTrain;
set(figErreurRC,'visible','on'); pause(10^-1);
DureeErreur = toc;

%% 5 - Tests suppl�mentaires
tic;
% testChaos;
DureeTests = toc;

Duree = DureeCible + DureeGenRes + DureeTrain + DureeErreur + DureeTests;