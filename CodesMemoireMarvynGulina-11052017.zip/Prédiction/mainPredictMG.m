% Emulation de syst�me chaotique par ESN
% **************************************

% Programme principal pour le MG
% ------------------------------

if ~exist('draplock','var')
    draplock = 0;
end

if draplock
    clc; close all;
else
    clc; close all; clearvars -except cas; format short;
end
tic;

%% 1 - Construction de la fonction cible
cibleMG;
% cibleMG2004;
% cibleMG_RK4; % Refaire �chantillonage pour fixer nbr de points

%% 2 - Construction du r�servoir
LvlNoise = 10^-6;
genResMG;
% genResMG2004;
% genResMG2010;

%% 3 - Entra�nement du r�servoir
% tic;
theta = round(0/h); % D�lai entre le RC et le MG : 0 par d�faut
trainSimpleMG;
% trainAvanceMG; % A mettre � jour

%% 4 - Calcul d'erreur et affichage
% tic;
calcErreursTrain;
set(figErreurRC,'visible','on'); pause(10^-1);

%% 5 - Tests suppl�mentaires
% tic;
% testAttracteursMG;
% testChaos; % A mettre � jour

Duree = toc;