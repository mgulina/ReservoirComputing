function y = minusPoint5(x)
y = x - 0.5;