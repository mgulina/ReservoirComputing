% Cryptographie chaotique
% ***********************

% Programme principal
% -------------------

clc; close all; clearvars; format short;

cas = menu('Choisissez la m�thode de transmission',...
                'Superposition','M�lange','Annuler');

pause(10^-1);
tic;
if cas == 1
    superposition;
%     set(figDecrypt,'visible','on'); pause(10^-1);
%     set(figErreurRC,'visible','on'); pause(10^-1);
    set(figCrack,'visible','on'); pause(10^-1);
elseif cas == 2   
    melange;
    set(signalsFig,'Visible','on');
else
    helpdlg('Programme avort�','Programme avort�');
    return;
end
toc